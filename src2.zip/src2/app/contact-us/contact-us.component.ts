import { Component, OnInit } from '@angular/core';
import {Contact} from '../contact';
import {ContactService} from '../contact.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
//   contact: Contact=new Contact; 
//   constructor(private service:ContactService) { }

//   ngOnInit(): void {
//     this.contact=new Contact();
//   }
//   saveFeedback()
//   {
//     this.service.createStudent(this.contact)
//     .subscribe(data=>{ 
//     console.log(data)},
//     error=>{console.log(error);
//     });
//   }
//   onSubmit()
//   { console.log(this.contact);
    
//      this.saveFeedback();
//     }

}
