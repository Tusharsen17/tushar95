export class Contact {
    id!: number;
    name!: string;
    contactno!: String;
    gender!: string;
    reasonforcontact!: string;
    password!: string;
}
